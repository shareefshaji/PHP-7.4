# php7

### For Install

```bash
git clone https://github.com/rdhoni/php7
cd php7
sh install.sh
```

### Error in device 32 bit 
if the error in a 32 bit device, please run the command below to fix this problem 

```bash
apt --fix-broken install
``` 
successfully fixed in device : 
- arm.x86
